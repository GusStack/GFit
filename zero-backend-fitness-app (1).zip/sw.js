self.addEventListener('install', e => {
  e.waitUntil(caches.open('zbf-cache-v1').then(c => c.addAll([
    '/', '/index.html', '/assets/styles.css', '/app/main.js', '/app/lib/router.js',
    '/app/components/HiitRunner.js', '/app/components/StrengthRunner.js', '/app/components/Settings.js',
    '/manifest.webmanifest', '/sw.js', '/data/exercises.json'
  ])));
});
self.addEventListener('fetch', e => {
  e.respondWith(caches.match(e.request).then(res => res || fetch(e.request)));
});